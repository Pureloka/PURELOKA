-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2021 at 04:20 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pureloka`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_employee` varchar(4) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id_employee`, `nama`, `username`, `password`) VALUES
('A001', 'Alfi F', 'alfi', '1'),
('A002', 'Aditya R', 'adit', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_booking`
--

CREATE TABLE `tb_booking` (
  `no_transaksi` varchar(50) NOT NULL,
  `idCard` varchar(50) NOT NULL,
  `kodeKamar` varchar(50) NOT NULL,
  `extrabed` tinyint(1) NOT NULL DEFAULT 0,
  `id_employee` varchar(50) DEFAULT NULL,
  `cekIn` date NOT NULL,
  `cekOut` date NOT NULL,
  `payment` varchar(50) DEFAULT 'Waiting',
  `status` varchar(50) DEFAULT 'Waiting'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tb_history`
--

CREATE TABLE `tb_history` (
  `no_transaksi` varchar(50) NOT NULL,
  `idCard` varchar(50) NOT NULL,
  `kodeKamar` varchar(50) NOT NULL,
  `extrabed` tinyint(1) NOT NULL DEFAULT 0,
  `id_employee` varchar(50) DEFAULT NULL,
  `cekIn` date NOT NULL,
  `cekOut` date NOT NULL,
  `payment` varchar(50) DEFAULT 'Waiting',
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_history`
--

INSERT INTO `tb_history` (`no_transaksi`, `idCard`, `kodeKamar`, `extrabed`, `id_employee`, `cekIn`, `cekOut`, `payment`, `status`) VALUES
('T0002', '33012345', 'Deluxe 201', 1, ' Alfi F(A001)', '2021-07-29', '2021-07-30', '-PAID-', 'Check Out'),
('T0003', '330123', 'Deluxe 202', 1, ' Alfi F(A001)', '2021-07-30', '2021-07-31', '-PAID-', 'Check Out'),
('T0004', '330101010101', 'Suite 102', 1, ' Alfi F(A001)', '2021-07-30', '2021-07-31', '-PAID-', 'Check Out'),
('T0005', '330101010101', 'Deluxe 202', 1, ' Alfi F(A001)', '2021-07-29', '2021-07-30', '-PAID-', 'Check Out'),
('T0006', '330101010101', 'Deluxe 201', 1, ' Alfi F(A001)', '2021-07-29', '2021-07-30', '-PAID-', 'Check Out'),
('T0007', '330101010101', 'Suite 101', 1, ' Alfi F(A001)', '2021-07-30', '2021-07-31', '-PAID-', 'Check Out');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `nama` varchar(50) NOT NULL,
  `idCard` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `phone` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`nama`, `idCard`, `password`, `phone`, `gender`) VALUES
('Kevin', '0987', '1', '0987', 'Male'),
('Rizqi Nur', '330101010101', 'rizqinur', '089', 'Male'),
('Adhesta P', '330123', 'adhesta', '0812', 'Male'),
('Tangguh Rizqi', '33012345', '1', '0812345', 'Male'),
('Sari Rahayu', '330123456', '08123456', '08123456', 'Female');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_employee`);

--
-- Indexes for table `tb_booking`
--
ALTER TABLE `tb_booking`
  ADD PRIMARY KEY (`no_transaksi`),
  ADD KEY `idCard` (`idCard`),
  ADD KEY `kodeKamar` (`kodeKamar`),
  ADD KEY `admin employee` (`id_employee`);

--
-- Indexes for table `tb_history`
--
ALTER TABLE `tb_history`
  ADD PRIMARY KEY (`no_transaksi`),
  ADD KEY `idCard` (`idCard`),
  ADD KEY `kodeKamar` (`kodeKamar`),
  ADD KEY `admin employee` (`id_employee`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`idCard`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
