import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nurwe
 */
public class bookingPage extends javax.swing.JInternalFrame {
    String logphone;
    String idLog;
    String noTransaksi;
    int suite=250000;
    int deluxe=450000;
    int luxury=750000;
    double total;
    double subtotal;
    double hargakamar;
    double cash;
    double kembalian;
    double extrabed=125000;
    
    private void autoNumber(){
        try{
                Connection c= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");             
                DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
                Statement st = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                String sql = "select max(right(no_transaksi,4)) from (SELECT no_transaksi FROM tb_booking UNION ALL SELECT "
                        + "no_transaksi FROM tb_history) as subQuery GROUP BY no_transaksi ORDER BY no_transaksi"; 
                ResultSet rs = st.executeQuery(sql);
                while(rs.next()){
            
                    if(rs.first()==false){
                        noTransaksi=("T0001");
                        fieldTransaksi.setText(noTransaksi);
                    }else{
                        rs.last();
                        int set_id = rs.getInt(1)+1;
                        String noTrans = String.valueOf(set_id);
                        int id_next = noTrans.length();
                        for(int i= 0; i<4 - id_next;i++){
                            noTrans = "0" + noTrans;
                        }
                        noTransaksi=("T"+noTrans);
                        fieldTransaksi.setText("T"+noTrans);
                    }
                }
            }catch(SQLException e){
                System.out.println("Error (AutoNumber))-"+e.getMessage());
            } 
    }
    
    public void cariID(){
        logphone = userLogin.phoneLogin.getText();
        System.out.println("logPhone cekinPage "+this.logphone);
        try{
            Connection koneksi= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");
            Statement s = koneksi.createStatement();
            String sql = "SELECT * FROM `tb_user` WHERE `phone`='"+logphone+"'";
            ResultSet rs = s.executeQuery(sql);
            if(rs.next()){
                idLog = rs.getString("idCard");
               
            }
            
            rs.close();s.close();
            System.out.println("ID : "+idLog);
            fieldidCard.setText(idLog);
        }catch(Exception e){
            System.out.println("error "+e.getMessage());
        }
        
    }
    private void insertBooking(){
        
        try{
            Connection koneksi= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");
            PreparedStatement stmt=null;
            String query = "INSERT INTO `tb_booking`(`no_transaksi`,`idCard`,`kodeKamar`, `extrabed`, `cekIn`, `cekOut`) VALUES (?,?,?,?,?,?)";
            stmt=koneksi.prepareStatement(query);
            stmt.setString(1,noTransaksi.toString());
            stmt.setString(2,fieldidCard.getText());
            stmt.setString(3,comboPilihKamar.getSelectedItem().toString());
            String extraBED;
            if(extraBed.isSelected()){
                extraBED="1";
                stmt.setString(4,extraBED);
            }else{
                extraBED="0";
                stmt.setString(4,extraBED);
            }
            stmt.setString(5,((JTextField)dateCekIn.getDateEditor().getUiComponent()).getText());
            stmt.setString(6,((JTextField)dateCekOut.getDateEditor().getUiComponent()).getText());
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Successful");
        }catch(SQLException ex){
            //JOptionPane.showMessageDialog(null,"Error");
            System.out.println("Insert booking Error "+ex.getMessage());
            }  
    }
    
    private void clearAll(){
        fieldTransaksi.setText("");
        fieldidCard.setText("");
        comboPilihKamar.setSelectedItem(null);
        extraBed.setSelected(false);
        dateCekIn.setCalendar(null);
        dateCekOut.setCalendar(null);
        textReceipt.setText("");
        
    }
    
    private void tampilKamar(){
            comboPilihKamar.addItem("Suite 101");
            comboPilihKamar.addItem("Suite 102");
            comboPilihKamar.addItem("Suite 103");
            comboPilihKamar.addItem("Deluxe 201");
            comboPilihKamar.addItem("Deluxe 202");
            comboPilihKamar.addItem("Deluxe 203");
            comboPilihKamar.addItem("Luxury 301");
            comboPilihKamar.addItem("Luxury 302");
            comboPilihKamar.addItem("Luxury 303");
    }   
    private void printReceipt(){
        textReceipt.setText(null);
        String kodeTrans=(String)fieldTransaksi.getText();
        String tipeK=(String)comboPilihKamar.getSelectedItem().toString();
        String cekin=(String)dateCekIn.getDate().toString();
        String cekout=(String)dateCekOut.getDate().toString();
        String extrabedd;
        if(extraBed.isSelected()){
            extrabedd=("125000");
        }else{
            extrabedd=(" - ");
        }
     
        
        textReceipt.append ("========================================="
                + "\n----------------------------- RECEIPT ----------------------------"
                + "\n------------------------------------------------------------------------"
                + "\n No. Pesanan\t: "+kodeTrans         
                + "\n------------------------------------------------------------------------"
                + "\n Cek In\t: "+cekin
                + "\n Cek Out\t: "+cekout
                + "\n Kamar\t: "+tipeK
                + "\n Extra Bed\t: Rp"+extrabedd
                + "\n------------------------------------------------------------------------"
                + "\n Total\t: Rp "+total
                + "\n========================================="
                );
    }
    private void hitung(){
        subtotal=0;
        
        if(extraBed.isSelected()==true){
                subtotal=subtotal+extrabed;            
            }else{       
            }
        
        if (comboPilihKamar.getSelectedItem().equals("Suite 101")||comboPilihKamar.getSelectedItem().equals("Suite 102")||comboPilihKamar.getSelectedItem().equals("Suite 103")){
                subtotal=subtotal+suite;
            }else if(comboPilihKamar.getSelectedItem().equals("Deluxe 201")||comboPilihKamar.getSelectedItem().equals("Deluxe 202")||comboPilihKamar.getSelectedItem().equals("Deluxe 203")){
                subtotal=subtotal+deluxe;               
            }else if(comboPilihKamar.getSelectedItem().equals("Luxury 301")||comboPilihKamar.getSelectedItem().equals("Luxury 302")||comboPilihKamar.getSelectedItem().equals("Luxury 303")){
                subtotal=subtotal+luxury;   
            }else{
                comboPilihKamar.setSelectedItem(null);
            }     
        
        try {
            
            DateFormat format = new SimpleDateFormat("dd MMMM yyyy");
            Date tanggalcekin = format.parse(dateCekIn.getDate().toString());
            Date tanggalcekout = format.parse((String)dateCekOut.getDate().toString());
            long tanggalcekin1 = tanggalcekin.getTime();
            long tanggalcekout1 = tanggalcekout.getTime();
            long diff = tanggalcekout1 - tanggalcekin1;
            long lama = diff / (24 * 60 * 60 * 1000);
            subtotal=subtotal*lama;
        } catch (Exception e) {
            System.out.println("Error hitung lama inap " + e.getMessage());
        }
        
        total=subtotal; 
    }
    /**
     * Creates new form cekinPage
     */
    public bookingPage() {
        initComponents();
        autoNumber();
        tampilKamar();
        cariID();
        buttonProcess.setEnabled(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        fieldidCard = new javax.swing.JTextField();
        comboPilihKamar = new javax.swing.JComboBox<>();
        buttonClear = new javax.swing.JButton();
        dateCekIn = new com.toedter.calendar.JDateChooser();
        dateCekOut = new com.toedter.calendar.JDateChooser();
        extraBed = new javax.swing.JCheckBox();
        fieldTransaksi = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        buttonProcess = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        buttonClear1 = new javax.swing.JButton();

        setBackground(new java.awt.Color(120, 122, 145));
        setForeground(new java.awt.Color(120, 122, 145));
        setPreferredSize(new java.awt.Dimension(740, 400));

        jPanel2.setBackground(new java.awt.Color(15, 4, 76));

        jLabel1.setBackground(new java.awt.Color(15, 4, 76));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Booking");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel2.setText("No. ID Card");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel8.setText("Pilih Kamar");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel9.setText("Check In");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel10.setText("Check Out");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel11.setText("Extra Bed");

        buttonClear.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        buttonClear.setText("Clear All");
        buttonClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonClearActionPerformed(evt);
            }
        });

        dateCekIn.setDateFormatString("yyyy-MM-dd");

        dateCekOut.setDateFormatString("yyyy-MM-dd");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel4.setText("No Transaksi");

        buttonProcess.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        buttonProcess.setText("Process");
        buttonProcess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonProcessActionPerformed(evt);
            }
        });

        textReceipt.setColumns(20);
        textReceipt.setRows(5);
        jScrollPane1.setViewportView(textReceipt);

        buttonClear1.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        buttonClear1.setText("Print");
        buttonClear1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonClear1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE))
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(comboPilihKamar, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldidCard, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dateCekOut, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
                            .addComponent(dateCekIn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldTransaksi, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(34, 34, 34))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(extraBed, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 123, Short.MAX_VALUE)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(243, 243, 243)
                .addComponent(buttonProcess)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(buttonClear)
                .addGap(13, 13, 13)
                .addComponent(buttonClear1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(fieldTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(fieldidCard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(comboPilihKamar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(extraBed, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel9)
                            .addComponent(dateCekIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10)
                            .addComponent(dateCekOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 21, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buttonClear)
                    .addComponent(buttonProcess)
                    .addComponent(buttonClear1))
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonClearActionPerformed
        clearAll();
    }//GEN-LAST:event_buttonClearActionPerformed

    private void buttonProcessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonProcessActionPerformed
        insertBooking();
    }//GEN-LAST:event_buttonProcessActionPerformed

    private void buttonClear1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonClear1ActionPerformed
        hitung();
        printReceipt();
        buttonProcess.setEnabled(true);
    }//GEN-LAST:event_buttonClear1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonClear;
    private javax.swing.JButton buttonClear1;
    private javax.swing.JButton buttonProcess;
    private javax.swing.JComboBox<String> comboPilihKamar;
    private com.toedter.calendar.JDateChooser dateCekIn;
    private com.toedter.calendar.JDateChooser dateCekOut;
    private javax.swing.JCheckBox extraBed;
    private javax.swing.JTextField fieldTransaksi;
    public static javax.swing.JTextField fieldidCard;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    public static final javax.swing.JTextArea textReceipt = new javax.swing.JTextArea();
    // End of variables declaration//GEN-END:variables
}
