import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Toolkit;
import java.awt.Dimension;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JTextField;
import javax.swing.table.TableModel;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nurwe
 */
public class admHome extends javax.swing.JFrame {
    private static Connection koneksi;
    private DefaultTableModel model,model1;
    
    
    String cekin;
    String cekout;
    
    int suite=250000;
    int deluxe=450000;
    int luxury=500000;
    double total;
    double subtotal;
    double hargakamar;
    double extrabed=125000;    
    
    String uName,admName,id_employee;
   
    private static Connection buka_koneksi(){
        
        if(koneksi==null){
            try{
                Connection koneksi= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");
                
                DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
                
            }catch(SQLException t){
                System.out.println("Error Connecting to mySQL."+t.getMessage());
            }
        }
        return koneksi;
    }
    
    public void cariID(){
        uName = admLogin.usernameLogin.getText();
        System.out.println("logUnameAdm "+this.uName);
        try{
            Connection koneksi= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");
            Statement s = koneksi.createStatement();
            String sql = "SELECT * FROM `tb_admin` WHERE `username`='"+uName+"'";
            ResultSet rs = s.executeQuery(sql);
            if(rs.next()){
                admName = rs.getString("nama");
                id_employee=rs.getString("id_employee");
                
            }
            
            rs.close();s.close();
            System.out.println("Admin\t : "+admName+"("+id_employee+")");
            labelHello11.setText(" "+admName+"("+id_employee+")");
        }catch(Exception e){
            System.out.println("error "+e.getMessage());
        }
        
    }
    public void autoNumber() {
        try{
                Connection koneksi= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");          
                DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
                Statement st = koneksi.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
               String sql = "select max(right(no_transaksi,4)) from (SELECT no_transaksi FROM tb_booking UNION ALL SELECT "
                        + "no_transaksi FROM tb_history) as subQuery GROUP BY no_transaksi ORDER BY no_transaksi";
                ResultSet rs = st.executeQuery(sql);
                while(rs.next()){
            
                    if(rs.first()==false){
                        fieldTransaksi.setText("T0001");
                    }else{
                        rs.last();
                        int set_id = rs.getInt(1)+1;
                        String noTrans = String.valueOf(set_id);
                        int id_next = noTrans.length();
                        for(int i= 0; i<4 - id_next;i++){
                            noTrans = "0" + noTrans;
                        }
                        fieldTransaksi.setText("T"+noTrans);
                    }
                }
                    
            }catch(SQLException e){
                System.out.println("Error (AutoNumber)."+e.getMessage());
            }
    }
    private void insertData(){
        try{                                          
            
            
                    
            Connection koneksi= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");
            PreparedStatement stmt1,stmt2;
           
            
            String query1 = "INSERT INTO `tb_booking`(`no_transaksi`,`idCard`,`kodeKamar`, `extrabed`, `cekIn`, `cekOut`,`id_employee`) VALUES (?,?,?,?,?,?,?)";
            stmt1=koneksi.prepareStatement(query1);
            stmt1.setString(1,fieldTransaksi.getText());
            stmt1.setString(2,fieldIdCard.getText());
            stmt1.setString(3,comboPilihKamar.getSelectedItem().toString());
            String extraBED;
            if(extraBed.isSelected()){
                extraBED="1";
                stmt1.setString(4,extraBED);
            }else{
                extraBED="0";
                stmt1.setString(4,extraBED);
            }
            stmt1.setString(5,((JTextField)dateCekIn.getDateEditor().getUiComponent()).getText());
            stmt1.setString(6,((JTextField)dateCekOut.getDateEditor().getUiComponent()).getText());
            stmt1.setString(7,labelHello11.getText());
            stmt1.executeUpdate();
            stmt1.close();
            
            String query2 = "INSERT INTO `tb_user`(`nama`, `idCard`, `phone`, `gender`) VALUES(?,?,?,?)";
            stmt2=koneksi.prepareStatement(query2);
            stmt2.setString(1,fieldNama.getText());
            stmt2.setString(2,fieldIdCard.getText());
            stmt2.setString(3,fieldPhone.getText());
            stmt2.setString(4,comboGender.getSelectedItem().toString());
            
            stmt2.executeUpdate();
            stmt2.close();
            
            
            
            JOptionPane.showMessageDialog(null,"Add Successful");
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Add Error");
            System.out.println("Add Error "+ex.getMessage());
        }  
    }
    private void ambilTableBooking(){
        model1.getDataVector().removeAllElements();
        model1.fireTableDataChanged();
        try{
            Connection c= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");
            Statement s = c.createStatement();
            String sql = "select b.no_transaksi,b.idCard,u.nama,u.gender,u.phone,b.kodeKamar,"
                    + " b.extrabed,b.id_employee,b.cekIn,b.cekOut,b.payment,b.status "
                    + "FROM tb_booking AS b LEFT JOIN tb_user as u on b.idCard=u.idCard;";
            ResultSet r = s.executeQuery(sql);
            
            while(r.next()){
                Object[] o = new Object[12];
                o[0]=r.getString("no_transaksi");
                o[1]=r.getString("idCard");
                o[2]=r.getString("nama");
                o[3]=r.getString("gender");
                o[4]=r.getString("phone");
                o[5]=r.getString("kodeKamar");
                o[6]=r.getString("extrabed");
                o[7]=r.getString("id_employee");
                o[8]=r.getString("cekIn");
                o[9]=r.getString("cekOut");
                o[10]=r.getString("payment");
                o[11]=r.getString("status");
                model1.addRow(o);
            }
            r.close();
            s.close();
            
            }catch(SQLException e){
                System.out.println("Error Ambil Table Booking "+e.getMessage());
            }
    }
    
    private void ambilTableHistory(){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        try{
            Connection koneksi= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");
            Statement s = koneksi.createStatement();
            String sql = "select h.no_transaksi,h.idCard,u.nama,u.gender,u.phone,h.kodeKamar,"
                    + " h.extrabed,h.id_employee,h.cekIn,h.cekOut,h.payment,h.status "
                    + "FROM tb_history AS h LEFT JOIN tb_user as u on h.idCard=u.idCard;";
            ResultSet r = s.executeQuery(sql);
            
            while(r.next()){
                Object[] o = new Object[12];
                o[0]=r.getString("no_transaksi");
                o[1]=r.getString("idCard");
                o[2]=r.getString("nama");
                o[3]=r.getString("gender");
                o[4]=r.getString("phone");
                o[5]=r.getString("kodeKamar");
                o[6]=r.getString("extrabed");
                o[7]=r.getString("id_employee");
                o[8]=r.getString("cekIn");
                o[9]=r.getString("cekOut");
                o[10]=r.getString("payment");
                o[11]=r.getString("status");
                model.addRow(o);
            }
           
            r.close();
            s.close();
            
            }catch(SQLException e){
                System.out.println("Error Table History"+e.getMessage());
            }
    }
    private void tampilKamar(){
            comboPilihKamar.addItem("Suite 101");
            comboPilihKamar.addItem("Suite 102");
            comboPilihKamar.addItem("Suite 103");
            comboPilihKamar.addItem("Deluxe 201");
            comboPilihKamar.addItem("Deluxe 202");
            comboPilihKamar.addItem("Deluxe 203");
            comboPilihKamar.addItem("Luxury 301");
            comboPilihKamar.addItem("Luxury 302");
            comboPilihKamar.addItem("Luxury 303");
    } 
    private void updateData(){
        try{
            String extraBED;
                if(extraBed.isSelected()){
                    extraBED="1";
                            
                }else{
                    extraBED="0";
                }
            Connection koneksi= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");
            String query =  "UPDATE `tb_booking` SET "
                        +"`no_transaksi`='"+fieldTransaksi.getText()+"',"
                        + "`idCard`='"+this.fieldIdCard.getText()+"',"
                        + "`kodeKamar`='"+this.comboPilihKamar.getSelectedItem().toString()+"',"
                        + "`extrabed`='"+extraBED.toString()+"',"
                        + "`id_employee`='"+labelHello11.getText()+"',"
                        + "`cekIn`='"+((JTextField)dateCekIn.getDateEditor().getUiComponent()).getText()+"',"
                        + "`cekOut`='"+((JTextField)dateCekOut.getDateEditor().getUiComponent()).getText()+"' "
                        + "WHERE `tb_booking`.`no_transaksi`='"+fieldTransaksi.getText()+"'";
                        
            PreparedStatement stat=(PreparedStatement)koneksi.prepareStatement(query);
            stat.executeUpdate();
            JOptionPane.showMessageDialog(this,"Edit Success");
                       
        }catch(SQLException ex){
            System.out.println("Error Edit data"+ex.getMessage());
        }
    }
        private void pindahRow(){
            try{
            
            Connection koneksi= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");
            PreparedStatement stmt=null;
            
            String query = "INSERT INTO `tb_history`(`no_transaksi`,`idCard`,`kodeKamar`, `extrabed`, `cekIn`, `cekOut`,`payment`,`status`,`id_employee`) VALUES (?,?,?,?,?,?,?,?,?)";
            
            stmt=koneksi.prepareStatement(query);
            stmt.setString(1,fieldTransaksi.getText());
            stmt.setString(2,fieldIdCard.getText());;
            stmt.setString(3,comboPilihKamar.getSelectedItem().toString());
            String extraBED;
            if(extraBed.isSelected()){
                extraBED="1";
                stmt.setString(4,extraBED);
            }else{
                extraBED="0";
                stmt.setString(4,extraBED);
            }
            stmt.setString(5,((JTextField)dateCekIn.getDateEditor().getUiComponent()).getText());
            stmt.setString(6,((JTextField)dateCekOut.getDateEditor().getUiComponent()).getText());
            String pay;
            if(confirmPay.isSelected()){
                pay="-PAID-";
                stmt.setString(7,pay);
            }else{
                pay="Waiting";
                stmt.setString(7,pay);
            }
            String Check;
            if(confirmCekin.isSelected()){
                Check="Check In";
                stmt.setString(8,Check);
            }else if (confirmCekout.isSelected()){
                Check="Check Out";
                stmt.setString(8,Check);
            }
            stmt.setString(9,labelHello11.getText());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Move Data Successful");
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Move Error");
            System.out.println("Pindah data Error "+ex.getMessage());
    }  
        }
    private void deleteData(){
        try {       
                Connection c= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");
                
                String sql="Delete from tb_booking "
                        + "Where `tb_booking`.`no_transaksi` ='"+this.fieldTransaksi.getText()+"'";
                    PreparedStatement p2=(PreparedStatement)
                    c.prepareStatement(sql);
                    p2.executeUpdate();
                    p2.close();
                    JOptionPane.showMessageDialog(this,"Delete Success");
                } catch (SQLException ex) {
                    System.out.println("Error "+ex.getMessage());
                }
    }
    private void resetForm(){
        fieldTransaksi.setText("");
        fieldIdCard.setText("");
        fieldNama.setText("");
        comboGender.setSelectedItem(null);
        fieldPhone.setText("");
        comboPilihKamar.setSelectedItem(null);
        extraBed.setSelected(false);
        dateCekIn.setCalendar(null);
        dateCekOut.setCalendar(null);
        confirmPay.setSelected(false);
        fieldKamar.setText(null);
        fieldExtrabed.setText(null);
        fieldLama.setText(null);
        fieldTotal.setText(null);
        fieldCash.setText(null);
        fieldKembalian.setText(null);
        buttonProcess.setEnabled(true); 
        confirmCekin.setSelected(false);
        confirmCekout.setSelected(false);
        textReceipt.setText("");
    }
    
    private void tampilComboGender(){
            comboGender.setSelectedItem(null);
        }
    
    private void printData(){
        String kodeTrans=(String)fieldTransaksi.getText();
        String nama=(String)fieldNama.getText();
        String gen=(String)comboGender.getSelectedItem().toString();
        String phone=(String)fieldPhone.getText();
        String adm=(String)labelHello11.getText();        
        String tipeK=(String)comboPilihKamar.getSelectedItem().toString();
        String cekin=(String)dateCekIn.getDate().toString();
        String cekout=(String)dateCekOut.getDate().toString();
        String total=(String)fieldTotal.getText();
        String cash = (String)fieldCash.getText();
        String kembalian= (String)fieldKembalian.getText();
        
        
        textReceipt.append ("======================================"
                + "\n------------------------ RECEIPT -------------------------"
                + "\n---------------------------------------------------------------"
                + "\n Admin\t: "+adm
                + "\n No. Pesanan\t: "+kodeTrans
                + "\n Nama\t: "+nama
                + "\n Gender\t: "+gen 
                + "\n Phone\t: "+phone           
                + "\n-------------------------------------"
                + "\n Cek In\t: "+cekin
                + "\n Cek Out\t: "+cekout
                + "\n Kamar\t: "+tipeK
                + "\n Total\t: "+total
                + "\n------------------------------------"
                + "\n Cash\t: Rp "+cash
                + "\n Kembali\t: "+kembalian     
                + "\n===================================="
                );
    }
    private void hitung(){
        subtotal=0;
        if(extraBed.isSelected()==true){
                fieldExtrabed.setText("Rp "+extrabed);
                subtotal=subtotal+extrabed;            
            }else{
                fieldExtrabed.setText("Rp 0");        
            }
        
        if (comboPilihKamar.getSelectedItem().equals("Suite 101")||comboPilihKamar.getSelectedItem().equals("Suite 102")||comboPilihKamar.getSelectedItem().equals("Suite 103")){
                fieldKamar.setText("Rp "+suite);
                subtotal=subtotal+suite;
            }else if(comboPilihKamar.getSelectedItem().equals("Deluxe 201")||comboPilihKamar.getSelectedItem().equals("Deluxe 202")||comboPilihKamar.getSelectedItem().equals("Deluxe 203")){
                fieldKamar.setText("Rp "+deluxe);
                subtotal=subtotal+deluxe;               
            }else if(comboPilihKamar.getSelectedItem().equals("President 301")||comboPilihKamar.getSelectedItem().equals("President 302")||comboPilihKamar.getSelectedItem().equals("President 303")){
                fieldKamar.setText("Rp "+luxury);
                subtotal=subtotal+luxury;   
            }else{
                comboPilihKamar.setSelectedItem(null);
            }     
        
        try {
            DateFormat format = new SimpleDateFormat("dd MMMM yyyy");
            Date tanggalcekin = format.parse(cekin);
            Date tanggalcekout = format.parse(cekout);
            long tanggalcekin1 = tanggalcekin.getTime();
            long tanggalcekout1 = tanggalcekout.getTime();
            long diff = tanggalcekout1 - tanggalcekin1;
            long lama = diff / (24 * 60 * 60 * 1000);
            fieldLama.setText(Long.toString(lama) + " Hari");
            subtotal=subtotal*lama;
        } catch (Exception e) {
            System.out.println("Error hitung lama inap " + e.getMessage());
        }
        
        total=subtotal;
        fieldTotal.setText("Rp "+total);
    
        fieldCash.setText(null);
    }
    private void updateProses(){
        String statusBooking;
            if(confirmCekin.isSelected()){
                    statusBooking="CheckIn";
                    confirmCekout.setSelected(false);
                    buttonDone.setEnabled(false);
                    
                }else{
                    statusBooking="CheckOut";
                    confirmCekin.setSelected(false);
                    buttonDone.setEnabled(false);
                }
        
        String confirmationPay;
            if(confirmPay.isSelected()){
                    confirmationPay="-PAID-";
                }else{
                    confirmationPay="Waiting";
                }
        
        try{
            Connection koneksi= DriverManager.getConnection("jdbc:mysql://localhost:3306/pureloka","root","");
            String query =  "UPDATE `tb_booking` SET "
                        + "`payment`='"+confirmationPay+"', "
                        + "`status`='"+statusBooking+"' "
                        + "WHERE `no_transaksi`='"+fieldTransaksi.getText()+"'";
                        
            PreparedStatement stat=(PreparedStatement)koneksi.prepareStatement(query);
            stat.executeUpdate();
            JOptionPane.showMessageDialog(this,"Edit Confirmation -Success-");
            }catch(Exception ex){
                System.out.println("Error Update data"+ex.getMessage());
            }
        
    }
    private void clickTableBooking(){
         int i = table_booking.getSelectedRow();
        TableModel model = table_booking.getModel();
            if(i==-1){
                return;
            }
        
        fieldTransaksi.setText(model.getValueAt(i,0).toString());
        fieldIdCard.setText(model.getValueAt(i,1).toString());
        fieldNama.setText(model.getValueAt(i,2).toString());
        String gender=model.getValueAt(i,3).toString();
            if (gender.equals("Male")){
                comboGender.setSelectedItem(gender);
            }else if(gender.equals("Female")){
                comboGender.setSelectedItem(gender);
            }else{
                comboGender.setSelectedItem(null);
            }
        fieldPhone.setText(model.getValueAt(i,4).toString());
        
        String pilihKam = model.getValueAt(i,5).toString();
            if (pilihKam.equals("Suite 101")){
                comboPilihKamar.setSelectedItem(pilihKam);
            }else if(pilihKam.equals("Suite 102")){
                comboPilihKamar.setSelectedItem(pilihKam);
            }else if(pilihKam.equals("Suite 103")){
                comboPilihKamar.setSelectedItem(pilihKam);
            }else if(pilihKam.equals("Deluxe 201")){
                comboPilihKamar.setSelectedItem(pilihKam);
            }else if(pilihKam.equals("Deluxe 202")){
                comboPilihKamar.setSelectedItem(pilihKam);
            }else if(pilihKam.equals("Deluxe 203")){
                comboPilihKamar.setSelectedItem(pilihKam);
            }else if(pilihKam.equals("President 302")){
                comboPilihKamar.setSelectedItem(pilihKam);
            }else if(pilihKam.equals("President 302")){
                comboPilihKamar.setSelectedItem(pilihKam);
            }else if(pilihKam.equals("President 302")){
                comboPilihKamar.setSelectedItem(pilihKam);
            }else{
                comboPilihKamar.setSelectedItem(null);
            }
        String extrabed = model.getValueAt(i,6).toString();
            if(extrabed.equals("1")){
                extraBed.setSelected(true);
            }else{
                extraBed.setSelected(false);
            }
        try{
            Date datecekin = new SimpleDateFormat("yyyy-MM-dd")
                .parse((String)model.getValueAt(i,8));
            Date datecekout = new SimpleDateFormat("yyyy-MM-dd")
                .parse((String)model.getValueAt(i,9));
        dateCekIn.setDate(datecekin);
        dateCekOut.setDate(datecekout);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null,"Error click table "+ex.getMessage());
        }
        String confirmationPay = model.getValueAt(i,10).toString();
            if(confirmationPay.equals("-PAID-")){
                confirmPay.setSelected(true);
            }else if(confirmationPay.equals("Waiting")){
                confirmPay.setSelected(false);
            }else if(confirmationPay.equals(null)){
                confirmPay.setSelected(false);
            }else{
                JOptionPane.showMessageDialog(null,"Error Payment Confirmation");
            }
        String statusBooking = model.getValueAt(i,11).toString();
            if(statusBooking.equals("CheckIn")){
                confirmCekin.setSelected(true);
                confirmCekout.setSelected(false);
            }else if(statusBooking.equals("CheckOut")){
                confirmCekin.setSelected(false);
                confirmCekout.setSelected(true);
            }else if(statusBooking.equals("Waiting")){
                confirmCekin.setSelected(false);
                confirmCekout.setSelected(false);
            }else{
                JOptionPane.showMessageDialog(null,"Error Payment Confirmation");
            }
            
     }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        groupCheck = new javax.swing.ButtonGroup();
        header = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        judul = new javax.swing.JLabel();
        buttonLogout = new javax.swing.JButton();
        labelHello11 = new javax.swing.JLabel();
        labelHello1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        Tab = new javax.swing.JTabbedPane();
        daftarKamar = new javax.swing.JScrollPane();
        table_booking = new javax.swing.JTable();
        history = new javax.swing.JScrollPane();
        table_history = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        fieldKamar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        fieldExtrabed = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        fieldLama = new javax.swing.JTextField();
        fieldTotal = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        fieldCash = new javax.swing.JTextField();
        fieldKembalian = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        buttonProcess = new javax.swing.JButton();
        buttonPrint = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        confirmPay = new javax.swing.JCheckBox();
        jLabel21 = new javax.swing.JLabel();
        buttonProcess1 = new javax.swing.JButton();
        buttonDone = new javax.swing.JButton();
        confirmCekin = new javax.swing.JRadioButton();
        confirmCekout = new javax.swing.JRadioButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        fieldTransaksi = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        fieldIdCard = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        fieldNama = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        comboGender = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        fieldPhone = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        comboPilihKamar = new javax.swing.JComboBox<>();
        extraBed = new javax.swing.JCheckBox();
        dateCekIn = new com.toedter.calendar.JDateChooser();
        dateCekOut = new com.toedter.calendar.JDateChooser();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        buttonAdd = new javax.swing.JButton();
        buttonEdit = new javax.swing.JButton();
        buttonRefresh = new javax.swing.JButton();
        buttonDelete = new javax.swing.JButton();
        buttonReset = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(0, 0));
        setMinimumSize(new java.awt.Dimension(1070, 650));
        setPreferredSize(new java.awt.Dimension(1070, 650));
        setSize(new java.awt.Dimension(1070, 650));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        header.setBackground(new java.awt.Color(15, 4, 76));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("BankGothic Md BT", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("PURELOKA");

        judul.setBackground(new java.awt.Color(255, 255, 255));
        judul.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        judul.setForeground(new java.awt.Color(255, 255, 255));
        judul.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        judul.setText("RESERVATION SYSTEM");

        buttonLogout.setText("Logout");
        buttonLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonLogoutActionPerformed(evt);
            }
        });

        labelHello11.setBackground(new java.awt.Color(255, 255, 255));
        labelHello11.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        labelHello11.setForeground(new java.awt.Color(255, 255, 255));
        labelHello11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        labelHello1.setBackground(new java.awt.Color(255, 255, 255));
        labelHello1.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        labelHello1.setForeground(new java.awt.Color(255, 255, 255));
        labelHello1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelHello1.setText("Login as : ");

        javax.swing.GroupLayout headerLayout = new javax.swing.GroupLayout(header);
        header.setLayout(headerLayout);
        headerLayout.setHorizontalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerLayout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(judul, javax.swing.GroupLayout.PREFERRED_SIZE, 570, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelHello1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelHello11, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        headerLayout.setVerticalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerLayout.createSequentialGroup()
                .addGroup(headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(judul, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonLogout))
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(headerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelHello11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(labelHello1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        getContentPane().add(header, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 50));

        jPanel1.setBackground(new java.awt.Color(78, 78, 78));

        table_booking.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table_booking.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table_bookingMouseClicked(evt);
            }
        });
        daftarKamar.setViewportView(table_booking);

        Tab.addTab("Books", daftarKamar);

        table_history.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        history.setViewportView(table_history);

        Tab.addTab("History", history);

        textReceipt.setColumns(20);
        textReceipt.setRows(5);
        jScrollPane1.setViewportView(textReceipt);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Room");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("TAX");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setText("Extra Bed");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setText("Lama");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setText("Total");

        fieldLama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldLamaActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setText("Cash");

        fieldCash.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                fieldCashCaretUpdate(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setText("Change");

        buttonProcess.setText("Process");
        buttonProcess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonProcessActionPerformed(evt);
            }
        });

        buttonPrint.setText("Print");
        buttonPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonPrintActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldCash))
                    .addComponent(jSeparator2)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldTotal))
                    .addComponent(jSeparator1)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldKembalian))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(fieldExtrabed, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fieldLama, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fieldKamar, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(buttonProcess)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(buttonPrint)
                        .addGap(31, 31, 31)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(fieldKamar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fieldExtrabed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(fieldLama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fieldTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 6, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fieldCash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fieldKembalian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buttonProcess)
                    .addComponent(buttonPrint))
                .addContainerGap())
        );

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("Check");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel19.setText("Check In");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel20.setText("Check Out    ");

        confirmPay.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        confirmPay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmPayActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setText("Paid");

        buttonProcess1.setText("Process");
        buttonProcess1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonProcess1ActionPerformed(evt);
            }
        });

        buttonDone.setText("Done");
        buttonDone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonDoneActionPerformed(evt);
            }
        });

        groupCheck.add(confirmCekin);

        groupCheck.add(confirmCekout);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel18, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(22, 22, 22)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(confirmPay)
                    .addComponent(confirmCekin)
                    .addComponent(confirmCekout))
                .addGap(20, 20, 20))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(buttonProcess1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(buttonDone, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(13, 13, 13))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel19)
                    .addComponent(confirmCekin))
                .addGap(8, 8, 8)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel20)
                    .addComponent(confirmCekout))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel21)
                    .addComponent(confirmPay))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(buttonProcess1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonDone)
                .addContainerGap())
        );

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel8.setText("No. Transaction");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel4.setText("ID Card");

        fieldIdCard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldIdCardActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel5.setText("Name");

        fieldNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNamaActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel6.setText("Gender");

        comboGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel7.setText("Phone");

        fieldPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldPhoneActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel11.setText("Room");

        dateCekIn.setDateFormatString("yyyy-MM-dd");
        dateCekIn.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                dateCekInPropertyChange(evt);
            }
        });

        dateCekOut.setDateFormatString("yyyy-MM-dd");
        dateCekOut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                dateCekOutMouseExited(evt);
            }
        });
        dateCekOut.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                dateCekOutPropertyChange(evt);
            }
        });
        dateCekOut.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                dateCekOutKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dateCekOutKeyTyped(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel10.setText("Check Out");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel9.setText("Check In");

        buttonAdd.setText("Add");
        buttonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAddActionPerformed(evt);
            }
        });

        buttonEdit.setText("Edit");
        buttonEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonEditActionPerformed(evt);
            }
        });

        buttonRefresh.setText("Refresh");
        buttonRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonRefreshActionPerformed(evt);
            }
        });

        buttonDelete.setText("Delete");
        buttonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonDeleteActionPerformed(evt);
            }
        });

        buttonReset.setText("Clear All");
        buttonReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonResetActionPerformed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel22.setText("Extra Bed");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(buttonAdd)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonEdit)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonRefresh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonDelete)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonReset)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(fieldPhone, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(dateCekIn, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(dateCekOut, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(extraBed, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(29, 29, 29)
                            .addComponent(comboPilihKamar, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(comboGender, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fieldIdCard)
                            .addComponent(fieldNama)
                            .addComponent(fieldTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(35, 35, 35))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fieldTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(fieldIdCard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(fieldNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(comboGender, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(fieldPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(comboPilihKamar, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(extraBed, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9)
                    .addComponent(dateCekIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel10)
                    .addComponent(dateCekOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 13, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buttonAdd)
                    .addComponent(buttonRefresh)
                    .addComponent(buttonDelete)
                    .addComponent(buttonEdit)
                    .addComponent(buttonReset))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(Tab))
                .addGap(27, 27, 27)
                .addComponent(namaaa, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(namaaa, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Tab, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(68, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 1100, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void buttonLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonLogoutActionPerformed
        userLogin log = new userLogin();
        log.setVisible(true);
        dispose();
    }//GEN-LAST:event_buttonLogoutActionPerformed

    private void buttonDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonDeleteActionPerformed
            deleteData();
            ambilTableBooking();
            ambilTableHistory();
            autoNumber();
            resetForm();
            
    }//GEN-LAST:event_buttonDeleteActionPerformed

    private void fieldNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldNamaActionPerformed

    private void fieldPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldPhoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldPhoneActionPerformed
    
    private void buttonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAddActionPerformed
        autoNumber();
        insertData();
        ambilTableBooking();
        ambilTableHistory();
        
    }//GEN-LAST:event_buttonAddActionPerformed
    
    private void buttonRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonRefreshActionPerformed
        ambilTableBooking();
        ambilTableHistory();
        autoNumber();
        
    }//GEN-LAST:event_buttonRefreshActionPerformed
           
    
    private void dateCekInPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_dateCekInPropertyChange
       if (dateCekIn.getDate() != null) {
            SimpleDateFormat FormatTanggal = new SimpleDateFormat("dd MMMM yyyy");
            cekin = FormatTanggal.format(dateCekIn.getDate());
            }
    }//GEN-LAST:event_dateCekInPropertyChange

    private void dateCekOutPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_dateCekOutPropertyChange
        if (dateCekOut.getDate() != null) {
            SimpleDateFormat FormatTanggal = new SimpleDateFormat("dd MMMM yyyy");
            cekout = FormatTanggal.format(dateCekOut.getDate());
            }
    }//GEN-LAST:event_dateCekOutPropertyChange

    private void dateCekOutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dateCekOutMouseExited
        
    }//GEN-LAST:event_dateCekOutMouseExited

    private void dateCekOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dateCekOutKeyReleased
        
    }//GEN-LAST:event_dateCekOutKeyReleased

    private void dateCekOutKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dateCekOutKeyTyped
        
    }//GEN-LAST:event_dateCekOutKeyTyped

    private void buttonPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonPrintActionPerformed
        textReceipt.setText(null);
        printData();
        ambilTableBooking();
        ambilTableHistory();
        autoNumber();        
    }//GEN-LAST:event_buttonPrintActionPerformed

    private void buttonEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonEditActionPerformed
        updateData();  
        ambilTableBooking();
        ambilTableHistory();
        autoNumber();
        
    }//GEN-LAST:event_buttonEditActionPerformed

    private void fieldIdCardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldIdCardActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldIdCardActionPerformed

    private void fieldLamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldLamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldLamaActionPerformed
    
    private void buttonProcessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonProcessActionPerformed
        hitung();
        buttonPrint.setEnabled(true);
    }//GEN-LAST:event_buttonProcessActionPerformed

    private void fieldCashCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_fieldCashCaretUpdate
        if (fieldCash.getText().equals(null)){
            JOptionPane.showMessageDialog(null, "Cash Tidak Boleh Kosong!");
        }else{
            int cash = Integer.parseInt(fieldCash.getText());
            double kembalian = cash-total;
            fieldKembalian.setText("Rp "+kembalian);
            
        }
        
    }//GEN-LAST:event_fieldCashCaretUpdate

    private void confirmPayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmPayActionPerformed
       
    }//GEN-LAST:event_confirmPayActionPerformed

    private void buttonResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonResetActionPerformed
       resetForm();
    }//GEN-LAST:event_buttonResetActionPerformed

    private void buttonProcess1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonProcess1ActionPerformed
        updateData();
        updateProses();
        ambilTableBooking();
        ambilTableHistory();
        if(confirmCekout.isSelected()&&confirmPay.isSelected()){
                    buttonDone.setEnabled(true);
                }
    }//GEN-LAST:event_buttonProcess1ActionPerformed

    private void table_bookingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table_bookingMouseClicked
        clickTableBooking();
    }//GEN-LAST:event_table_bookingMouseClicked

    private void buttonDoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonDoneActionPerformed
        pindahRow();
        deleteData();
        ambilTableBooking();
        ambilTableHistory();
       
    }//GEN-LAST:event_buttonDoneActionPerformed
    
    
     /**
     * Creates new form Home
     */
    
    
    public admHome() {
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2, size.height/2 -getHeight()/2);
        cariID();
        autoNumber();
              
        
        model1=new DefaultTableModel();
        this.table_booking.setModel(model1);
        model1.addColumn("No. Transaction");
         model1.addColumn("ID Card");
         model1.addColumn("Name");
         model1.addColumn("Gender");
         model1.addColumn("Phone");
         model1.addColumn("Room Code");
         model1.addColumn("Extra Bed");
         model1.addColumn("Staff ID");
         model1.addColumn("Cek-In Date");
         model1.addColumn("Cek-Out Date");
         model1.addColumn("Payment");
         model1.addColumn("Status");
        ambilTableBooking();
        
        model=new DefaultTableModel();
        this.table_history.setModel(model);
         model.addColumn("No. Transaction");
         model.addColumn("ID Card");
         model.addColumn("Name");
         model.addColumn("Gender");
         model.addColumn("Phone");
         model.addColumn("Room Code");
         model.addColumn("Extra Bed");
         model.addColumn("Staff ID");
         model.addColumn("Cek-In Date");
         model.addColumn("Cek-Out Date");
         model.addColumn("Payment");
         model.addColumn("Status");
        ambilTableHistory();
        
        tampilComboGender();
        tampilKamar();
        buttonDone.setEnabled(false);
        buttonPrint.setEnabled(false);
    }
    
    public static void main(String args[]) {
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admHome().setVisible(true);
            }
        });
    }
    
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane Tab;
    private javax.swing.JButton buttonAdd;
    private javax.swing.JButton buttonDelete;
    private javax.swing.JButton buttonDone;
    private javax.swing.JButton buttonEdit;
    private javax.swing.JButton buttonLogout;
    private javax.swing.JButton buttonPrint;
    private javax.swing.JButton buttonProcess;
    private javax.swing.JButton buttonProcess1;
    private javax.swing.JButton buttonRefresh;
    private javax.swing.JButton buttonReset;
    private javax.swing.JComboBox<String> comboGender;
    private javax.swing.JComboBox<String> comboPilihKamar;
    private javax.swing.JRadioButton confirmCekin;
    private javax.swing.JRadioButton confirmCekout;
    private javax.swing.JCheckBox confirmPay;
    private javax.swing.JScrollPane daftarKamar;
    private com.toedter.calendar.JDateChooser dateCekIn;
    private com.toedter.calendar.JDateChooser dateCekOut;
    private javax.swing.JCheckBox extraBed;
    private javax.swing.JTextField fieldCash;
    private javax.swing.JTextField fieldExtrabed;
    private javax.swing.JTextField fieldIdCard;
    private javax.swing.JTextField fieldKamar;
    private javax.swing.JTextField fieldKembalian;
    private javax.swing.JTextField fieldLama;
    private javax.swing.JTextField fieldNama;
    private javax.swing.JTextField fieldPhone;
    private javax.swing.JTextField fieldTotal;
    private javax.swing.JTextField fieldTransaksi;
    private javax.swing.ButtonGroup groupCheck;
    private javax.swing.JPanel header;
    private javax.swing.JScrollPane history;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel judul;
    private javax.swing.JLabel labelHello1;
    private javax.swing.JLabel labelHello11;
    public static final javax.swing.JLabel namaaa = new javax.swing.JLabel();
    private javax.swing.JTable table_booking;
    private javax.swing.JTable table_history;
    public static final javax.swing.JTextArea textReceipt = new javax.swing.JTextArea();
    // End of variables declaration//GEN-END:variables
}
